package app.yummytv

object Config {
    // ВСТАВЬТЕ СЮДА токен приложения со страницы https://yummyani.me/dev/applications
    // (между кавычками, вместо PASTE_YOUR_TOKEN_HERE)
    const val APP_TOKEN = "PASTE_YOUR_TOKEN_HERE"

    const val BASE_URL = "https://api.yani.tv/"
    const val SITE = "https://yummyani.me"
}
